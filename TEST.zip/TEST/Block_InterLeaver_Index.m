function output= Block_InterLeaver_Index(inputdata,len,a) 


n=1:len; 
m =  1 + mod(a*n,len);
output= inputdata(m) ;