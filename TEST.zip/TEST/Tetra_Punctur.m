function [data_out ,class1dataDepunch, class2dataDepunch]= Tetra_Punctur(data_in,channel_type,Punctur_flag)
% Punctur= BNCH, BSCH SCH_HU SCH_F TCH_24 TCH_48
% Punctur_flag=Punctur, DePunctur; 
data_out = [];
class1dataDepunch=[];
class2dataDepunch = [];
if(strcmp(channel_type,'BNCH')||strcmp(channel_type,'STCH')||   strcmp(channel_type,'SCH/H'))
       t=3; P=[1,2,5];
    if(strcmp(Punctur_flag,'DePuncture'))
   data_out = zeros(1,144*4);	 
	  for n=1:216
        m=n;
     	k=8*floor((m-1)/t)+P(m-t*floor((m-1)/t));
        data_out(k) = data_in(m);     
      end
    else %% Punctur
      data_out = zeros(1,216);	 
	  for n=1:216
        m=n;
     	k=8*floor((m-1)/t)+P(m-t*floor((m-1)/t));
        data_out(m) = data_in(k);     
      end
    end
end

if(strcmp(channel_type,'SCH/S'))
       t=3; P=[1,2,5];
    if(strcmp(Punctur_flag,'DePuncture'))
   data_out = zeros(1,80*4);% 
	  for n=1:120
        m=n;
     	k=8*floor((m-1)/t)+P(m-t*floor((m-1)/t));
        data_out(k) = data_in(m);     
      end
    else %% Punctur
      data_out = zeros(1,120);	 
	  for n=1:120
        m=n;
     	k=8*floor((m-1)/t)+P(m-t*floor((m-1)/t));
        data_out(m) = data_in(k);     
      end
    end
end

if(strcmp(channel_type,'SCHHU'))
       t=3; P=[1,2,5];
    if(strcmp(Punctur_flag,'DePuncture'))
   data_out = zeros(1,112*4);	 
	  for n=1:168
        m=n;
     	k=8*floor((m-1)/t)+P(m-t*floor((m-1)/t));
        data_out(k) = data_in(m);     
      end
    else %% Punctur
      data_out = zeros(1,168);	 
	  for n=1:168
        m=n;
     	k=8*floor((m-1)/t)+P(m-t*floor((m-1)/t));
        data_out(m) = data_in(k);     
      end
    end
end

if(strcmp(channel_type,'TCH48'))
       t=3; P=[1,2,5];
    if(strcmp(Punctur_flag,'DePuncture'))
   data_out = zeros(1,292*4);	 
	  for n=1:432
        m=n+floor((n-1)/65);
     	k=8*floor((m-1)/t)+P(m-t*floor((m-1)/t));
        data_out(k) = data_in(n);     
      end
    else %% Punctur
      data_out = zeros(1,432);	 
	  for n=1:432
        m=n+floor((n-1)/65);
     	k=8*floor((m-1)/t)+P(m-t*floor((m-1)/t));
        data_out(n) = data_in(k);     
      end
    end
end

if(strcmp(channel_type,'TCH24'))
       t=6; P=[1,2,3,5,6,7];
    if(strcmp(Punctur_flag,'DePuncture'))
      data_out = zeros(1,148*4);	 
	  for n=1:432
        m=n+floor((n-1)/35);
     	k=8*floor((m-1)/t)+P(m-t*floor((m-1)/t));
        data_out(k) = data_in(n);     
      end
    else %% Punctur
      data_out = zeros(1,432);	 
	  for n=1:432
        m=n+floor((n-1)/35);
     	k=8*floor((m-1)/t)+P(m-t*floor((m-1)/t));
        data_out(n) = data_in(k);     
      end
    end
end

if(strcmp(channel_type,'SCHF') )
       t=3; P=[1,2,5];
    if(strcmp(Punctur_flag,'DePuncture'))
   data_out = zeros(1,288*4);	 
	  for n=1:432
        m=n;
     	k=8*floor((m-1)/t)+P(m-t*floor((m-1)/t));
        data_out(k) = data_in(m);     
      end
    else %% Punctur
      data_out = zeros(1,432);	 
	  for n=1:432
        m=n;
     	k=8*floor((m-1)/t)+P(m-t*floor((m-1)/t));
        data_out(m) = data_in(k);     
      end
    end
end


if(strcmp(channel_type,'TCH/S'))

   t=3;P=[1 2 4];Period=6;%2/3
   kp=[];
   % class1data  = data_in(103:103+167);
   class1data  = data_in(136:136+134);
   class1dataDepunch = zeros(1,336);
   for n=1:135%168%2*56*3/2
        m=n;
     	k=Period*floor((m-1)/t)+P(m-t*floor((m-1)/t));
        kp=[kp,k];
        class1dataDepunch(k) = class1data(m);     
   end
   


   t=9;P=[1,2,3,4,5,7,8,10,11];Period=12;%8/18
   % class2data  = data_in(103+168:103+168+161);
   class2data  = data_in(136+135:136+135+161);
   class2dataDepunch = zeros(1,216);
   kp=[];
   for n=1:162%(2*30+8+4)*18/8
        m=n;
     	k=Period*floor((m-1)/t)+P(m-t*floor((m-1)/t));
        kp=[kp,k];
        class2dataDepunch(k) = class2data(m);     
   end

end