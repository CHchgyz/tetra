

load("y.mat")
y = (1-2*y(1:end));
for i=1:length(y)-length(trainSeq)

    corrvalue(i)=y(i:i+length(trainSeq)-1)*(1-2*trainSeq)';

end
figure;plot(abs(corrvalue))

channeltype ='DSB';
demoduvalue1 = y([95:214]);
% demoduvalue1 =demoduvalue(95:214);% demoduvalue(95:214);
demoduvalue1 = demoduvalue1./max(abs(demoduvalue1))*127;

deScrambleData=descrambleFunc(demoduvalue1,channeltype);
deInterleaveData=Block_InterLeaver_Index(deScrambleData,120,11);
data_out = Tetra_Punctur(deInterleaveData,'SCH/S','DePuncture') ;
trel = poly2trellis(5,[31 27 35 33]);%%% 
decoded_bits= vitdec(data_out,trel,80,'term','unquant');
% decoded_bits = vitdec_tb(data_out,4);

crcflag = CRCFunc(decoded_bits(1:end),'CRC16');
