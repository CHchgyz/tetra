function  data=descrambleFunc(InputData,channeltype)
if strcmp(channeltype,'DSB')
    e30 = zeros(1,30);
  
else
    e30 = [de2bi(86,10,'left-msb') de2bi(23,14,'left-msb'),de2bi(1,6,'left-msb')];%86 23 1
end
  len=length(InputData);


    p32 = zeros(1,32); p32(32)=1; p32(31)=1; % the rightmost is the oldest data
    p32(1:30) = e30;
    DeScrSeq432 = zeros(1,432);
for n=1:len
   p0=(p32(1)+p32(2)+p32(4)+p32(5)+p32(7)+p32(8)+p32(10)+p32(11)+p32(12)...
		             +p32(16)+p32(22)+p32(23)+p32(26)+p32(32));
   p0 = mod(p0,2);
   p32(2:32)=p32(1:31);
   p32(1) = p0;
   DeScrSeq432(n)=p0; % 
   data(n) = (1-2*p0)*InputData(n);
end
aa=1;
% data=xor(InputData,DeScrSeq432);



