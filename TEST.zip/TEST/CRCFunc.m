function   flag =  CRCFunc(inputData,type)

if strcmp(type,'CRC16')
    crcGen = [1 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 1];      % CRC generator polynosequence
elseif strcmp(type,'CRC7')
    crcGen = [1 0 0 1 0 0 0 1];      % CRC generator polynosequence  
elseif strcmp(type,'CRC4')
    crcGen = [1 1 0 0 1];      % CRC generator polynosequence  
end

crclen=length(crcGen)-1;

reg=zeros(1,crclen);
len = length(inputData);

for i=1:len
       input=reg(end);  
       for j=crclen:-1:2
           if(crcGen(j)==1)
              reg(j)=xor(input,reg(j-1));
           else
              reg(j)=reg(j-1);
           end
       end
       reg(1)=xor(input,inputData(i));
end
if sum(reg)==0
    flag=0;
else
     flag=1;
end
